const supabaseUrl = 'https://twpvmxsrljejauowthxq.supabase.co'; const supabaseKey = 'sb_publishable_wUcYIRySgzOfiR6z_HmkQg_GazUbYqS';
